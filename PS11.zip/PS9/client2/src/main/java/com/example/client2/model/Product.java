package com.example.client2.model;

public class Product {
    private String name;
    private String producer;
    private Double price;

    public Product() {
    }

    public Product(String name, String producer, Double price) {
        this.name = name;
        this.producer = producer;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProducer() {
        return producer;
    }

    public void setProducer(String producer) {
        this.producer = producer;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product:\n" +
                "name=" + name + '\n' +
                "producer=" + producer + '\n' +
                "price=" + price + '\n';
    }
}
